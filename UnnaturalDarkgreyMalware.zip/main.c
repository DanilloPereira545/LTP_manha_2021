//Projeto: Exercico 3.
//autor : Danillo Gabriel Pereira Santos.
//inicio do programa 
#include <stdio.h>
//inicio.
int main(void) {
 float e_A, e_B, s_A, s_B;
 //insira o valor A.
 printf("Valor de A:\n");
  scanf( "%f", &e_A);
  //insira o valor de B.
  printf("Valor de B:\n");
  scanf( "%f", &e_B);
  //logica "vice-versa".
  s_A = e_B;
  s_B = e_A;
  {
 printf("Saida de A: %.0f \n", s_A);
 printf("Saida de B: %.0f \n", s_B);
  }
//fim.
  return 0;
}